//escenario
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8B21E4); 
scene.fog = new THREE.Fog(0x161616, 3, 6);


var loader = new  THREE.TextureLoader();
loader.load(
    '../img/Fondo2.jpg', function(texture){
     scene.background = texture;
    }
);

//camara
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

//render
const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

//geometria

const geometry = new THREE.SphereGeometry( 2, 50, 50 );
const material = new THREE.MeshBasicMaterial( { color: 0x13A020 } );
const sphere = new THREE.Mesh( geometry, material );
scene.add( sphere );

//line

const edges = new THREE.EdgesGeometry( geometry );
const line = new THREE.LineSegments( edges, new THREE.LineBasicMaterial( { color: 0x000000} ) );
scene.add( line );

camera.position.z = 5;

//animacion
function animate() {
    requestAnimationFrame( animate );
    sphere.rotation.x += 0.04;
    sphere.rotation.y += 0.04;
    sphere.rotation.z += 0.00;
    line.rotation.x += 0.04;
    line.rotation.y += 0.04;
    line.rotation.z += 0.00;
    renderer.render( scene, camera );
}
animate();