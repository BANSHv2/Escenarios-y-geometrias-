//escenario
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8B21E4); 
scene.fog = new THREE.Fog(0xFF0000, 3, 6);
const material = new THREE.LineBasicMaterial({
	color: 0x000000
});

var loader = new  THREE.TextureLoader();
loader.load(
    '../img/Fondo.jpg', function(texture){
     scene.background = texture;
    }
);
const points = [];
points.push( new THREE.Vector3( - 10, 0, 0 ) );
points.push( new THREE.Vector3( 0, 10, 0 ) );
points.push( new THREE.Vector3( 10, 0, 0 ) );

const geometry = new THREE.BufferGeometry().setFromPoints( points );

const line = new THREE.Line( geometry, material );
scene.add( line );



//camara
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );

//render
const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

//geometria

const geometry2 = new THREE.BoxGeometry( 1, 1, 1 );
const material2 = new THREE.MeshBasicMaterial( { color: 0xA1A1A1} );
const cube = new THREE.Mesh( geometry2, material2 );
scene.add( cube );

camera.position.z = 5;

//animacion
function animate() {
    requestAnimationFrame( animate );
    cube.rotation.x += 0.03;
    cube.rotation.y += 0.01;
    cube.rotation.z += 0.2;
    renderer.render( scene, camera );
}
animate();